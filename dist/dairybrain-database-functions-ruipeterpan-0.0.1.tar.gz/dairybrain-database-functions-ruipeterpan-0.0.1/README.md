# AgDH_database_functions

See [this](https://packaging.python.org/tutorials/packaging-projects/) tutorial for guidance on packaging a Python project and uploading it to the PyPI (Python Package Index).
[This](https://github.com/pypa/sampleproject) is a sample project with the best format.


## About
AgDH_database_functions is a PyPI package with some basic functionalities for interacting with a database along with some other Dairy-Brain-specific functionalities.

## Placeholder for an actual README